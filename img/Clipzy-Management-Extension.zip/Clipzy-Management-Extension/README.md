# Clipzy Website Blocker Chrome Extension

## Overview
The Clipzy Website Blocker Chrome Extension is a management tool designed for Clipzy employees to restrict access to certain websites on managed Chrome browsers within the Google Workspace environment. It allows administrators to enforce the installation of the extension across specified organizational units, ensuring a secure and productive work environment.

## Features
- Blocks access to specified websites associated with adult content and Facebook.
- Redirects users to a custom page when attempting to access blocked websites.
- Easy-to-use regex system for managing the list of blocked websites.
- Lightweight and unobtrusive, running in the background of the Chrome browser.
