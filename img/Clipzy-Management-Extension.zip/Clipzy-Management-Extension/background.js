const blockedPatterns = [
    /(^|\.)porn/,
    /(^|\.)xxx/,
    /(^|\.)xvideos/,
    /(^|\.)pornhub/,
    /(^|\.)xhamster/,
    /(^|\.)redtube/,
    /(^|\.)youporn/,
    /(^|\.)tube8/,
    /(^|\.)xnxx/,
    /(^|\.)spankbang/,
    /(^|\.)facebook\.com/
];

function isBlocked(url) {
    return blockedPatterns.some(pattern => pattern.test(url));
}

chrome.webRequest.onBeforeRequest.addListener(
    function(details) {
        if (isBlocked(details.url)) {
          return { redirectUrl: chrome.extension.getURL("blocked.html") };
        }
    },
    {urls: ["<all_urls>"]},
    ["blocking"]
);
